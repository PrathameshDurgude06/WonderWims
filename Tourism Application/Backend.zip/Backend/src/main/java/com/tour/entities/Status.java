package com.tour.entities;

public enum Status {
	SUCCESS,FAILED,PENDING
}
