package com.tour.entities;

public enum Role {
	ADMIN,CUSTOMER
}
